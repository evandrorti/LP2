﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class fmCalc : Form
    {
        public fmCalc()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tbRaio.Text = "";
            tbAltura.Text = "";
            tbResultado.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tbRaio_TextChanged(object sender, EventArgs e)
        {


            double Raio, Altura, Resultado;

            if (tbRaio.Text.Length > 0 && tbAltura.Text.Length > 0)
            {
                double.TryParse(tbRaio.Text, out Raio);
                double.TryParse(tbAltura.Text, out Altura);
                Resultado = Math.PI * Math.Pow(Raio, 2) * Altura;
                tbResultado.Text = Resultado.ToString();
            }

        }

        private void tbRaio_KeyDown(object sender, KeyEventArgs e)
        {


        

        }

        private void tbRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            double Raio, Altura, Resultado;

            if (tbRaio.Text.Length > 0 && tbAltura.Text.Length > 0)
            {
                double.TryParse(tbRaio.Text, out Raio);
                double.TryParse(tbAltura.Text, out Altura);
                Resultado = Math.PI * Math.Pow(Raio, 2) * Altura;
                tbResultado.Text = Resultado.ToString();
            }
        }

        private void tbAltura_KeyUp(object sender, KeyEventArgs e)
        {
            double Raio, Altura, Resultado;

            if (tbRaio.Text.Length > 0 && tbAltura.Text.Length > 0)
            {
                double.TryParse(tbRaio.Text, out Raio);
                double.TryParse(tbAltura.Text, out Altura);
                Resultado = Math.PI * Math.Pow(Raio, 2) * Altura;
                tbResultado.Text = Resultado.ToString();
            }
        }
    }
}
