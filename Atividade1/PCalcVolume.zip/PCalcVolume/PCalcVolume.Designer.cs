﻿namespace WindowsFormsApplication1
{
    partial class fmCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbRaio = new System.Windows.Forms.TextBox();
            this.lbRaio = new System.Windows.Forms.Label();
            this.lbAltura = new System.Windows.Forms.Label();
            this.tbAltura = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbResultado = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btCalcular = new System.Windows.Forms.Button();
            this.btSair = new System.Windows.Forms.Button();
            this.btLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbRaio
            // 
            this.tbRaio.Location = new System.Drawing.Point(75, 42);
            this.tbRaio.Name = "tbRaio";
            this.tbRaio.Size = new System.Drawing.Size(100, 20);
            this.tbRaio.TabIndex = 0;
            this.tbRaio.TextChanged += new System.EventHandler(this.tbRaio_TextChanged);
            this.tbRaio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbRaio_KeyDown);
            this.tbRaio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbRaio_KeyPress);
            // 
            // lbRaio
            // 
            this.lbRaio.AutoSize = true;
            this.lbRaio.Location = new System.Drawing.Point(30, 49);
            this.lbRaio.Name = "lbRaio";
            this.lbRaio.Size = new System.Drawing.Size(29, 13);
            this.lbRaio.TabIndex = 1;
            this.lbRaio.Text = "Raio";
            this.lbRaio.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbAltura
            // 
            this.lbAltura.AutoSize = true;
            this.lbAltura.Location = new System.Drawing.Point(31, 85);
            this.lbAltura.Name = "lbAltura";
            this.lbAltura.Size = new System.Drawing.Size(34, 13);
            this.lbAltura.TabIndex = 2;
            this.lbAltura.Text = "Altura";
            this.lbAltura.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // tbAltura
            // 
            this.tbAltura.Location = new System.Drawing.Point(75, 78);
            this.tbAltura.Name = "tbAltura";
            this.tbAltura.Size = new System.Drawing.Size(100, 20);
            this.tbAltura.TabIndex = 3;
            this.tbAltura.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbAltura_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "Calculadora de Volume";
            // 
            // tbResultado
            // 
            this.tbResultado.Location = new System.Drawing.Point(75, 117);
            this.tbResultado.Name = "tbResultado";
            this.tbResultado.ReadOnly = true;
            this.tbResultado.Size = new System.Drawing.Size(100, 20);
            this.tbResultado.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Volume";
            // 
            // btCalcular
            // 
            this.btCalcular.Location = new System.Drawing.Point(8, 150);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(75, 23);
            this.btCalcular.TabIndex = 7;
            this.btCalcular.Text = "Calcular";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.tbRaio_TextChanged);
            // 
            // btSair
            // 
            this.btSair.Location = new System.Drawing.Point(176, 150);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(37, 23);
            this.btSair.TabIndex = 8;
            this.btSair.Text = "Sair";
            this.btSair.UseVisualStyleBackColor = true;
            this.btSair.Click += new System.EventHandler(this.button2_Click);
            // 
            // btLimpar
            // 
            this.btLimpar.Location = new System.Drawing.Point(88, 150);
            this.btLimpar.Name = "btLimpar";
            this.btLimpar.Size = new System.Drawing.Size(75, 23);
            this.btLimpar.TabIndex = 9;
            this.btLimpar.Text = "Limpar";
            this.btLimpar.UseVisualStyleBackColor = true;
            this.btLimpar.Click += new System.EventHandler(this.button3_Click);
            // 
            // fmCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(218, 185);
            this.Controls.Add(this.btLimpar);
            this.Controls.Add(this.btSair);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbResultado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbAltura);
            this.Controls.Add(this.lbAltura);
            this.Controls.Add(this.lbRaio);
            this.Controls.Add(this.tbRaio);
            this.Name = "fmCalc";
            this.Text = "PVolume v1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbRaio;
        private System.Windows.Forms.Label lbRaio;
        private System.Windows.Forms.Label lbAltura;
        private System.Windows.Forms.TextBox tbAltura;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbResultado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.Button btSair;
        private System.Windows.Forms.Button btLimpar;
    }
}

