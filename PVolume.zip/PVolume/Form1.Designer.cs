﻿namespace PVolume
{
    partial class frPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btSair = new System.Windows.Forms.Button();
            this.btLimpar = new System.Windows.Forms.Button();
            this.brCalcular = new System.Windows.Forms.Button();
            this.tbRaio = new System.Windows.Forms.TextBox();
            this.lbEntrada = new System.Windows.Forms.Label();
            this.lbResultado = new System.Windows.Forms.Label();
            this.tbResultado = new System.Windows.Forms.TextBox();
            this.gbEntrada = new System.Windows.Forms.GroupBox();
            this.rbRaio = new System.Windows.Forms.RadioButton();
            this.rbDiametro = new System.Windows.Forms.RadioButton();
            this.lbSaida = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.gbEntrada.SuspendLayout();
            this.SuspendLayout();
            // 
            // btSair
            // 
            this.btSair.Location = new System.Drawing.Point(187, 148);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(40, 23);
            this.btSair.TabIndex = 0;
            this.btSair.Text = "Sair";
            this.btSair.UseVisualStyleBackColor = true;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // btLimpar
            // 
            this.btLimpar.Location = new System.Drawing.Point(93, 148);
            this.btLimpar.Name = "btLimpar";
            this.btLimpar.Size = new System.Drawing.Size(75, 23);
            this.btLimpar.TabIndex = 1;
            this.btLimpar.Text = "Limpar";
            this.btLimpar.UseVisualStyleBackColor = true;
            this.btLimpar.Click += new System.EventHandler(this.btLimpar_Click);
            // 
            // brCalcular
            // 
            this.brCalcular.Location = new System.Drawing.Point(12, 148);
            this.brCalcular.Name = "brCalcular";
            this.brCalcular.Size = new System.Drawing.Size(75, 23);
            this.brCalcular.TabIndex = 2;
            this.brCalcular.Text = "Calcular";
            this.brCalcular.UseVisualStyleBackColor = true;
            // 
            // tbRaio
            // 
            this.tbRaio.Location = new System.Drawing.Point(67, 48);
            this.tbRaio.Name = "tbRaio";
            this.tbRaio.Size = new System.Drawing.Size(160, 20);
            this.tbRaio.TabIndex = 3;
            this.tbRaio.TextChanged += new System.EventHandler(this.tbRaio_TextChanged);
            this.tbRaio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbRaio_KeyDown);
            // 
            // lbEntrada
            // 
            this.lbEntrada.AutoSize = true;
            this.lbEntrada.Location = new System.Drawing.Point(12, 55);
            this.lbEntrada.Name = "lbEntrada";
            this.lbEntrada.Size = new System.Drawing.Size(29, 13);
            this.lbEntrada.TabIndex = 4;
            this.lbEntrada.Text = "Raio";
            // 
            // lbResultado
            // 
            this.lbResultado.AutoSize = true;
            this.lbResultado.Location = new System.Drawing.Point(12, 105);
            this.lbResultado.Name = "lbResultado";
            this.lbResultado.Size = new System.Drawing.Size(55, 13);
            this.lbResultado.TabIndex = 7;
            this.lbResultado.Text = "Resultado";
            // 
            // tbResultado
            // 
            this.tbResultado.Enabled = false;
            this.tbResultado.Location = new System.Drawing.Point(67, 102);
            this.tbResultado.Name = "tbResultado";
            this.tbResultado.Size = new System.Drawing.Size(160, 20);
            this.tbResultado.TabIndex = 8;
            // 
            // gbEntrada
            // 
            this.gbEntrada.Controls.Add(this.rbDiametro);
            this.gbEntrada.Controls.Add(this.rbRaio);
            this.gbEntrada.Location = new System.Drawing.Point(13, 3);
            this.gbEntrada.Name = "gbEntrada";
            this.gbEntrada.Size = new System.Drawing.Size(211, 40);
            this.gbEntrada.TabIndex = 9;
            this.gbEntrada.TabStop = false;
            this.gbEntrada.Text = "Entrada";
            // 
            // rbRaio
            // 
            this.rbRaio.AutoSize = true;
            this.rbRaio.Checked = true;
            this.rbRaio.Location = new System.Drawing.Point(6, 13);
            this.rbRaio.Name = "rbRaio";
            this.rbRaio.Size = new System.Drawing.Size(47, 17);
            this.rbRaio.TabIndex = 0;
            this.rbRaio.TabStop = true;
            this.rbRaio.Text = "Raio";
            this.rbRaio.UseVisualStyleBackColor = true;
            this.rbRaio.CheckedChanged += new System.EventHandler(this.rbRaio_CheckedChanged);
            this.rbRaio.Click += new System.EventHandler(this.rbRaio_Click);
            // 
            // rbDiametro
            // 
            this.rbDiametro.AutoSize = true;
            this.rbDiametro.Location = new System.Drawing.Point(82, 12);
            this.rbDiametro.Name = "rbDiametro";
            this.rbDiametro.Size = new System.Drawing.Size(67, 17);
            this.rbDiametro.TabIndex = 1;
            this.rbDiametro.Text = "Diametro";
            this.rbDiametro.UseVisualStyleBackColor = true;
            this.rbDiametro.CheckedChanged += new System.EventHandler(this.rbDiametro_CheckedChanged);
            // 
            // lbSaida
            // 
            this.lbSaida.AutoSize = true;
            this.lbSaida.Location = new System.Drawing.Point(12, 80);
            this.lbSaida.Name = "lbSaida";
            this.lbSaida.Size = new System.Drawing.Size(29, 13);
            this.lbSaida.TabIndex = 10;
            this.lbSaida.Text = "Raio";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(67, 73);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(160, 20);
            this.textBox1.TabIndex = 11;
            // 
            // frPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(232, 183);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbSaida);
            this.Controls.Add(this.gbEntrada);
            this.Controls.Add(this.tbResultado);
            this.Controls.Add(this.lbResultado);
            this.Controls.Add(this.lbEntrada);
            this.Controls.Add(this.tbRaio);
            this.Controls.Add(this.brCalcular);
            this.Controls.Add(this.btLimpar);
            this.Controls.Add(this.btSair);
            this.Name = "frPrincipal";
            this.Text = "Calculadora de Volume";
            this.Load += new System.EventHandler(this.frPrincipal_Load);
            this.gbEntrada.ResumeLayout(false);
            this.gbEntrada.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btSair;
        private System.Windows.Forms.Button btLimpar;
        private System.Windows.Forms.Button brCalcular;
        private System.Windows.Forms.TextBox tbRaio;
        private System.Windows.Forms.Label lbEntrada;
        private System.Windows.Forms.Label lbResultado;
        private System.Windows.Forms.TextBox tbResultado;
        private System.Windows.Forms.GroupBox gbEntrada;
        private System.Windows.Forms.RadioButton rbRaio;
        private System.Windows.Forms.RadioButton rbDiametro;
        private System.Windows.Forms.Label lbSaida;
        private System.Windows.Forms.TextBox textBox1;
    }
}

